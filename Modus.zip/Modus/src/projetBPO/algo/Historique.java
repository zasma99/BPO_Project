package projetBPO.algo;

import projetBPO.jeux.IEtat;

import java.util.ArrayList;

public class Historique {
    private ArrayList<IEtat> ali;

    public Historique(){
        this.ali = new ArrayList<IEtat>() ;
    }


    void ajouter (IEtat etat){
        ali.add(etat);
    }

    boolean contient(IEtat etat){
        return (ali.contains(etat));
    }

    @Override
    public String toString() {
        return "Historique{" +
                "ali=" + ali +
                '}';
    }
}
