package projetBPO.algo;

import projetBPO.jeux.EtatAvecEtatFinalPredefini;
import projetBPO.jeux.IEtat;

import java.util.Iterator;
import java.util.LinkedList;

public class LargeurDAbord implements IRecherche {

    private LinkedList<IEtat> lie ;

    public LargeurDAbord(){
        this.lie = new LinkedList<IEtat>();
    }

    @Override
    public boolean existeChemin(IEtat etat) {

        Historique h = new Historique();
        return existeChemin(etat , h);
    }

    public boolean existeChemin(IEtat etat , Historique h){
        boolean trouve = etat.estFinal();

        LinkedList<IEtat> supp =new LinkedList<>();
        IEtat first, last;

        Iterator<IEtat> it = etat.iterator();

        lie.add(etat);
        if(etat.estFinal()){
            trouve = true;
        }

        while(it.hasNext()){
            lie.add(it.next());
        }
        System.out.println("Succ des mots"+lie);


        while(!lie.isEmpty()){
            first = lie.getFirst();
            System.out.println("Premier mot de la file: "+first);
            h.ajouter(first);
            System.out.println("etat historique: "+h);

            if (first.estFinal()){
                return true;
            } else{
                if(!h.contient(first)) {
                    h.ajouter(first);
                    System.out.println("Historique des états: "+h);
                    last = lie.removeFirst();
                    System.out.println("Element supprimé: "+last);
                }else {return false;}


            }



        }

        return trouve;
    }
}
