package projetBPO.algo;

import projetBPO.jeux.IEtat;

public interface IRecherche {
    boolean existeChemin(IEtat etat);
}
