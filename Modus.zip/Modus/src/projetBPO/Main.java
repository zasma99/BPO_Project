package projetBPO;

import projetBPO.algo.LargeurDAbord;
import projetBPO.jeux.Dictionnaire;
import projetBPO.algo.ProfondeurDAbord;
import projetBPO.jeux.JeuDeMots;

import static projetBPO.jeux.EtatAvecEtatFinalPredefini.setEtatFinal;
import static projetBPO.jeux.JeuDeMots.setDico;

public class Main {

    public static void main (String[] args){
        String[] mots = {"tare" , "vaisseau","gase" , "rase" , "mare" , "mate"};
        Dictionnaire dico = new Dictionnaire();
        dico.setMots(mots);
        System.out.println(dico);
        ProfondeurDAbord depth = new ProfondeurDAbord();
        LargeurDAbord length = new LargeurDAbord();

        JeuDeMots game = new JeuDeMots("pare");
        setDico(dico);

        setEtatFinal(new JeuDeMots("gars"));
        boolean presence = depth.existeChemin(game);

        System.out.println("Le résultat de la construction: " + presence);

        setEtatFinal(new JeuDeMots("gare"));
        presence = depth.existeChemin(game);

        System.out.println("Le résultat de la construction: " + presence);

        setEtatFinal(new JeuDeMots("mare"));
        presence = length.existeChemin(game);
        System.out.println("Le résultat de la construction: " + presence);
    }
}
