package projetBPO.jeux;

import projetBPO.jeux.algo.ProfondeurDabord;

import static projetBPO.jeux.EtatAvecEtatFinalPredefini.setEtatFinal;
import static projetBPO.jeux.JeuDeMots.setDico;

public class Main {

    public static void main (String[] args){
        String[] mots = {"gare" , "vaisseau","gase" , "rase" , "mare" , "mate"};
        Dictionnaire dico = new Dictionnaire();
        dico.setMots(mots);

        ProfondeurDabord depth = new ProfondeurDabord();
        JeuDeMots game = new JeuDeMots("Gare");
        setDico(dico);

        setEtatFinal(new JeuDeMots("gars"));
        boolean presence = depth.existeChemin(game);

        System.out.println("Le résultat de la construction: " + presence);


    }
}
