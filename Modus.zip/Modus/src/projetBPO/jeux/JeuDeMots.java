package projetBPO.jeux;

import java.util.ArrayList;
import java.util.Iterator;

public class JeuDeMots extends EtatAvecEtatFinalPredefini {
    static Dictionnaire dico;
    private String word ;

    public JeuDeMots(String mot){
        this.word = mot;
    }


    public static void setDico(Dictionnaire dico) {
        JeuDeMots.dico = dico;
    }

    public Iterator<IEtat> iterator(){

        ArrayList<IEtat> succ = new ArrayList<IEtat>();
        //Iterator<IEtat> it = succ.iterator();

        StringBuilder mot ;//= new StringBuilder(word.toLowerCase());
        JeuDeMots possible ;
        //StringBuilder apn = new StringBuilder(this.word);
        for (int nol = 0; nol < word.length(); nol++) {
            for (char lettre = 'a'; lettre <= 'z'; lettre++){
                mot = new StringBuilder(word.toLowerCase());
                //System.out.print(lettre+"----");
                //System.out.print((char)mot.charAt(nol)+"---");
                if ((char)mot.charAt(nol) != lettre) {
                    mot.setCharAt(nol, lettre);
                    //System.out.println(mot + " = "+dico.contient(mot.toString()));
                    if (dico.contient(mot.toString())) {
                        possible = new JeuDeMots(mot.toString());
                        succ.add(possible);
                    }

                }
                //System.out.println("Mot après modification:" + mot);

            }

        }
        //System.out.println(succ.size());
        return succ.iterator() ;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JeuDeMots iEtats = (JeuDeMots) o;

        return word.equals(iEtats.word);
    }

    @Override
    public int hashCode() {
        return word.hashCode();
    }


    @Override
    public String toString() {
        return "JeuDeMots{" + "word='" + word + '\'' + '}';
    }
}
