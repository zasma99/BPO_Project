package projetBPO.jeux.algo;

import projetBPO.jeux.IEtat;

import java.util.Iterator;
import java.util.ListIterator;

public class ProfondeurDabord implements IRecherche {

    public ProfondeurDabord() {
    }

    @Override
    public boolean existeChemin(IEtat etat) {
        Historique h = new Historique();
        //h.ajouter(etat);
        return existeChemin(etat , h);
    }

    private boolean existeChemin(IEtat etat , Historique h){
       boolean trouve = etat.estFinal();

       if(trouve){ return true ; }

        Iterator<IEtat> it = etat.iterator();

       while (!trouve && it.hasNext()){
           //h.ajouter(etat)  ;
          // IEtat elm = it.next();
           if (!h.contient(etat)) {
              h.ajouter(etat);
               trouve = existeChemin(it.next(), h);        //concurrentModificationException
           } else return false;
       }
       return trouve ;
    }

    public static void main(String[] args){
        ProfondeurDabord depth = new ProfondeurDabord();
    }
}

