package projetBPO.jeux;

import projetBPO.algos.ProfondeurDAbord;
import projetBPO.jeux.jeudemots.Dictionnaire;
import projetBPO.jeux.jeudemots.JeuDeMots;

import static projetBPO.jeux.EtatAvecEtatFinalPredefini.setEtatFinal;
import static projetBPO.jeux.jeudemots.JeuDeMots.setDico;


public class Main {

    public static void main (String[] args){
        String[] mots = {"gare" , "vaisseau","gase" , "rase" , "mare" , "gate"};
        Dictionnaire dico = new Dictionnaire();
        dico.setMots(mots);

        ProfondeurDAbord depth = new ProfondeurDAbord();
        JeuDeMots game = new JeuDeMots("Gare");
        setDico(dico);
        dico.toString();

        JeuDeMots finale =  new JeuDeMots("gate");
        setEtatFinal(finale);
        boolean presence = depth.existeChemin(game);

        System.out.println("Le résultat de la recherche par profondeur pour le mot final "+ finale +": " + presence);


    }
}
