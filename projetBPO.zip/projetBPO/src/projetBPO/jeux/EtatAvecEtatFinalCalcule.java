package projetBPO.jeux;

public abstract class EtatAvecEtatFinalCalcule implements IEtat{

    protected static EtatAvecEtatFinalPredefini etatFinal;

    public boolean estFinal() {
        return etatFinal.equals(this);
    }
}
