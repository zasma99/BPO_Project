package projetBPO.jeux.oups;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class Passage {
    private Piece[] tlc = new Piece[100];
    private Piece salle1 , salle2;
   // private Passage pass;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Passage passage = (Passage) o;
        return Arrays.equals(tlc, passage.tlc) &&
                Objects.equals(salle1, passage.salle1) &&
                Objects.equals(salle2, passage.salle2);
    }


    public Passage(Piece salle1, Piece salle2 , Piece[] commandes) {
        this.salle1 = salle1;
        this.salle2 = salle2;
        for(int i = 0; i < commandes.length ; i++ ){
            this.tlc[i] = commandes[i];
        }
    }

    /*void link(Piece no1 , Piece no2){ // Création d'un nouveau passage qui lie deux pièces? Utile?
       pass = new Passage(no1 , no2);
    }*/

     // A compléter
    // Je ne vois pas à quoi cette méthode correspond


    public Piece getSalle1() {
        return salle1;
    }

    public Piece getSalle2() {
        return salle2;
    }

    @Override
    public String toString() {
        return "Passage entre {" + "salle" + salle1.getNoPiece( )+ ", salle" + salle2.getNoPiece()+'}';
    }
}
