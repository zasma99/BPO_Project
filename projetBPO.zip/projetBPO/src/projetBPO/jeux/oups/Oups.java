package projetBPO.jeux.oups;

import projetBPO.jeux.EtatAvecEtatFinalCalcule;
import projetBPO.jeux.EtatAvecEtatFinalPredefini;
import projetBPO.jeux.IEtat;

import java.util.ArrayList;
import java.util.Iterator;

/*
Reste à faire:
    - Modifier itérateur
    - Mettre en place une méthode qui assure le déplacement du robot sur le plateau
    - Vérifier si on place les pièces dans le monde ou dans la classe Oups
    - Revoir la méthode qui commande l'ouverture des trappes
    - Revoir la classe Passage
 */

public class Oups extends EtatAvecEtatFinalCalcule { // Méthode qui permet le mouvement du robot sur le plateau?

    private static Monde m;
    private int nosalleRobot;
    private CollectionPieces piecesOuvertes; // Pourquoi?
    private Piece current;

    public Oups(Monde m, int nosalleRobot) {
        this.m = m;
        this.nosalleRobot = nosalleRobot;
    }

    /**
     * Ouvre une trappe
     * @AssetionError  s'il n'y a pas de trappe dans la pièce renseignée
     * @param noSalle
     */
    public void ouvrirTrappe(int noSalle){

        Piece current = m.getPiecesMonde().element(noSalle);

        if(current.presenceTrappe() || current.getEtatTrappe() == 0){
            current.setEtatTrappe(1);
        }
        assert(current.presenceTrappe()): "La salle ne possède pas de trappe ";

    }

    /**
     * Met en places les pièces du jeu
     * @param piecesOuvertes
     */
    public void setPiecesJeu(CollectionPieces piecesOuvertes) {
        this.piecesOuvertes = piecesOuvertes;
    }

    /**
     * @return numéro de salle du robot
     */
    public int getNosalleRobot() {
        return nosalleRobot;
    }

    public Iterator<IEtat>  iterator() {

        ArrayList<IEtat> succ = new ArrayList<>();
        Oups possible;
        Piece salleRobot = m.getPiecesMonde().element(nosalleRobot);
        for(int i = 0 ; i < m.getPiecesMonde().getSize() ; i++) {
                System.out.println("Salle robot "+salleRobot);
                System.out.println(m.getPiecesMonde().element(i));
                if(m.getPassagesMonde().contient(salleRobot , m.getPiecesMonde().element(i))){
                    Monde mn = new Monde(m.getNbSalles());
                    CollectionPieces co = m.getPiecesMonde();
                    System.out.println(co.toString());
                    co.remove(nosalleRobot);
                    System.out.println(co.toString());
                    mn.setPiecesMonde(co);
                    possible = new Oups(m , i);
                    succ.add(possible);
                }
         }
        return succ.iterator();
        // A revoir
    }

    /**
     * @return true si le robot a atteint une pièce avec un trésor
     */
    @Override
    public boolean estFinal() {
        Piece salleRobot = m.getPiecesMonde().element(nosalleRobot);
        if (salleRobot.getEtatTrappe() == 0 && salleRobot.etatTresor()){
            return true;
        }
        return false;
    }

    public static void main(String[] args){
        /***** Mise en place des éléments nécéssaires à la création du monde et du jeu *****/

       /* Piece room = new Piece(false ,true , 1 , 0);
        Piece room1 = new Piece(true ,false , 2 , 1);
        Piece room2 = new Piece(true ,true , 3 , 0);

        ArrayList<Piece> alp = new ArrayList<>();
        alp.add(room); alp.add(room1); alp.add(room2);  //Ensemble des pièces du jeu

        Passage way = new Passage(room , room1);    //Création du premier passage

        ArrayList<Passage> alpa = new ArrayList<>();    //Création des passages dans le jeu
        alpa.add(way);

        CollectionPieces pieces = new CollectionPieces(alp);
        CollectionPassages passages = new CollectionPassages(alpa);*/

        /********************** CREATION DU JEU ET MANIPULATIONS BASIQUES **********************************/

       /* Monde world = new Monde(15);
        Oups game = new Oups(world ,1);     //Création du monde et jeu

        Piece pieceRobot = new Piece(room.getNoPiece());
        game.setPiecesJeu(pieces);

        world.setPassagesMonde(passages);
        world.setPiecesMonde(pieces);

        Iterator<IEtat> it = game.iterator();

        IEtat state ;
        while(it.hasNext()){ state = it.next();}


        world.ajouterPassage(room1.getNoPiece() , room2.getNoPiece()); // Création du second passage

        System.out.println(passages.toString());    //Affichage des différents passages du jeu

        game.ouvrirTrappe(1);
        if(room.presenceTrappe()) {
            System.out.println("Il existe une trappe dans la salle n°"+room.getNoPiece()+".");
        }else{
            System.out.println("Il n'y a pas de trappe dans cette salle , du moins pour le moment!");
        }

        if(pieceRobot.etatTresor()) {
            System.out.println("Le trésor se trouve dans la salle n°"+pieceRobot.getNoPiece()+".");
        }
        else{
            System.out.println("Le trésor n'y ait pas! Continuez la recherche!");
        }

        System.out.println(pieceRobot.toString());
        Piece p = new Piece(10);
        System.out.println(p.toString());

        p = new Piece();
        System.out.println(p.toString());       //Création avec des attributs par défaut égaux à false

        System.out.println(room2.toString());
        world.ajouterOuvertureFermetureTrappe(3 , 1 , 2);
        System.out.println(room2.toString());*/
    }
}
