package projetBPO.jeux.oups;

public class Piece {
    private boolean trappe;
    private int etatTrappe;
    private boolean tresor;
    private int noPiece;
    //private CollectionPassages passages;


    public Piece(boolean trappe, int etatTrappe , boolean tresor, int noPiece) {
        this.trappe = trappe;
        this.tresor = tresor;
        this.noPiece = noPiece;
        this.etatTrappe = etatTrappe;
    }

    /**
     * Création d'une pièce en ayant seulement un numéro de salle
     */
    public Piece(int noPiece){
        int nombreAleatoire = (int)(Math.random() * ((1 - 0) + 1));
        this.noPiece = noPiece;
        if (nombreAleatoire == 0) {
            this.trappe = false;
            this.etatTrappe = 0;
            this.tresor = false ;
        } else { this.trappe = true ; this.tresor = false ; this.etatTrappe = 1 ;}
    }

    /**
     * Création d'une pièce par défaut
     */
    public Piece(){} // Création d'une pièce sans aucun attribut

    /**
     * Constructeur de copie

    public Piece(Piece p){
        this.salle = p;
    }

     */

    public int getNoPiece() {
        return noPiece;
    }

    /*public CollectionPassages waysLinkedTo() {
        return passages;
    } */
    // Inutile sauf si on décide quechaque pièce du monde est liée à plusieurs passages ici

    public boolean etatTresor() {
        return tresor;
    }

    /**
     * @return true s'il y a une trappe dans la piece
     */
    public boolean presenceTrappe() { return trappe;  }

    /**
     * @return 1 si la trappe est ouverte et 0 si elle est fermée
     */
    public int getEtatTrappe() {
        return etatTrappe;
    }

    public void setEtatTrappe(int etatTrappe) {
        this.etatTrappe = etatTrappe;
    }

    public void setTresor(boolean tresor) {
        this.tresor = tresor;
    }

    public void setNoPiece(int noPiece) {
        this.noPiece = noPiece;
    }

    /*public void setPassages(CollectionPassages passages) {
        this.passages = passages;
    } Inutile*/

    @Override
    public String toString() {
        return "Piece n°" + noPiece + ":" + " présence trappe = " + trappe + " , état trappe = " + etatTrappe + " , tresor = " + tresor ;
    }
}
