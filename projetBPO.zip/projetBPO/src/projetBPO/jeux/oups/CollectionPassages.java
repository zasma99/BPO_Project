package projetBPO.jeux.oups;

import java.util.ArrayList;

public class CollectionPassages {

    private ArrayList<Passage> lcpass = new ArrayList<>();
    //private Passage p;

    public CollectionPassages(Passage... lcp) {
        for(Passage p : lcp) {
            this.lcpass.add(p);
        }
    }



    /**
     * Ajoute un passage à la collection déjà existante
     * @param p
     */
    public void add(Passage p) {
        lcpass.add(p);
    }

    /**
     * @param salle1
     * @param salle2
     * @return true si le passage entre les 2 pièces est contenu dans la collection
     */
    public boolean contient(Piece salle1 , Piece salle2){ //Modifier
        /*Passage p = new Passage(salle1 , salle2);
        return lcpass.contains(p);*/
        for(Passage p : lcpass){
            if(p.getSalle1().equals(salle1) && p.getSalle2().equals(salle2)){
                return true;
            }
        }
        return false;
    }

    public Passage passageI(Piece salle1 , Piece salle2){
        Piece[] trappe = {salle1};
        for(Passage p : lcpass){
            if(p.getSalle1() == salle1 && p.getSalle2() == salle2){
                return p;
            }
        }
        return new Passage(salle1 , salle1 , trappe);
    }

    @Override
    public String toString() {
        return "CollectionPassages{"+ lcpass +
                '}';
    }
}
