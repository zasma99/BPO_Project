package projetBPO.jeux.oups;

public class Monde {
    private int nbSalles;
    private CollectionPieces piecesMonde;
    private CollectionPassages passagesMonde;
    //private Passage way;
   // private Piece piece1 , piece2 , piege;

    public Monde(int nbSalles) {
        this.nbSalles = nbSalles;
    }

    /**
     * Met en place les différentes dans le monde
     * @param piecesMonde
     */
    public void setPiecesMonde(CollectionPieces piecesMonde) { // Mettre en place les pièces du monde ici ou dans Oups
        this.piecesMonde = piecesMonde;
    }

    /**
     * Met en place les différents passges du monde
     * @param passagesMonde
     */
    public void setPassagesMonde(CollectionPassages passagesMonde) {
        this.passagesMonde = passagesMonde;
    }

    public CollectionPieces getPiecesMonde() {
        return piecesMonde;
    }

    public CollectionPassages getPassagesMonde() {
        return passagesMonde;
    }

    /**
     * @return le nombre de salles du monde
     */
    public int getNbSalles() {
        return nbSalles;
    }

    /**
     * @AssertionError si le passage existe déjà dans le monde
     * @param noSalle1 salle 1
     * @param noSalle2 salle 2
     */
    public void ajouterPassage(int noSalle1, int noSalle2){
        //Passage way = new Passage(piece1, piece2);
        Piece[] trappe = new Piece[nbSalles];

        if(this.piecesMonde.contains(noSalle1) || this.piecesMonde.contains(noSalle2)) {
            Passage way = new Passage(this.piecesMonde.element(noSalle1), this.piecesMonde.element(noSalle2) , trappe);
            passagesMonde.add(way);
        }
    }

    /**
     * Commande l'ouverture ou la fermeture d'une trappe
     *
     *  @AssertionError si le passage entre les deux pièces n'existe pas
     *  @AssertionError s'il n'y a pas de trappe dans la salle renseignée
     * @param noSalleTrappe
     * @param noSalle1
     * @param noSalle2
     */

    public void ajouterOuvertureFermetureTrappe(int noSalleTrappe , int noSalle1 , int noSalle2) {
        // Comment faire en sorte que lors du passage entre les deux pièces l'état des trappes soit modifié?

        Piece piece1 , piece2 , piege;
        Passage p ;
        piece1 = this.piecesMonde.element(noSalle1);
        piece2 = this.piecesMonde.element(noSalle2);
        piege = this.piecesMonde.element(noSalleTrappe);
        p = this.passagesMonde.passageI(piece1 , piece2);
        //assert(passagesMonde.contient(piece1, piece2) || piege.presenceTrappe()): "Les données saisies sont incorrectes!";

        if (piege.getEtatTrappe() == 0) {
            piege.setEtatTrappe(1);
        } else {
            piege.setEtatTrappe(0);
        }


    }




    /*public CollectionPieces getPiecesMonde() {
        return piecesMonde;
    }*/

    /**
     * Permet de rajouter un trésor dans une pièce
     * @param noSalle numéro de salle
     */
    void ajouterTresor(int noSalle){
        Piece piece1 = new Piece(noSalle);
        piece1.setTresor(true);
        // Cela impliquerai la crétion d'une nouvelle pièce avec un numéro de salle déjà présent sur le plateau de jeu : RESOLU
        // Dans collectionPieces : Essayer de mettre en place une méthode qui permet de retrouver une pièce dans une collection de pièces déjà initialisée à l'aide du numéro de salle : RESOLU
    }
}
