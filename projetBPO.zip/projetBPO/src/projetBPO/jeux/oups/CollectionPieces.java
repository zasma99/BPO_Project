package projetBPO.jeux.oups;

import projetBPO.jeux.IEtat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class CollectionPieces implements Iterable<IEtat> {
    private ArrayList<Piece> alp = new ArrayList<>();
    private Piece room ;

    public CollectionPieces(Piece... alp) {
        for(Piece p :alp) {
            this.alp.add(p);
        }
    }

    public Iterator<IEtat> iterator(){
        ArrayList<IEtat> als = new ArrayList<>();
        return als.iterator(); // A revoir
    }

    public int getSize() {
        return alp.size();
    }

    public Piece element(int noSalle){
        for(Piece p : alp){
            if(p.getNoPiece() == noSalle){
                return p;
            }
        }
        return new Piece();
    }

    /**
     * @param noSalle
     * @return true si la pièce est dans la collection
     */
    public boolean contains(int noSalle){
        for(Piece p : alp){
            if(p.getNoPiece() == noSalle){
                return true;
            }
        }
        return false;

    }

    public void remove(int noSalle){
        this.alp.remove(element(noSalle));
    }

    @Override
    public String toString() {
        return "CollectionPieces{" + "alp=" + alp + '}';
    }

    /**
     * @param noSalle
     * @return la salle présente dans la collection

    public Piece getPieceFromCollection(int noSalle) {
        Piece room = new Piece(noSalle);
        Piece wrongRoom = new Piece();
        for(int i =0 ; i< alp.size() ; i++){
            if(alp.contains(room)){
                return alp.get(i);
            }

        }
        return wrongRoom;
    } // Mettre une exception*/
}

