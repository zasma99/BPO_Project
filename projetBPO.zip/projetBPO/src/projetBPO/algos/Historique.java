package projetBPO.algos;

import projetBPO.jeux.IEtat;

import java.util.LinkedList;

public class Historique {
    private LinkedList<IEtat> ali = new LinkedList<>() ;

    public Historique(){
    }

    void ajouter (IEtat etat){
        ali.add(etat);
    }

    boolean contient(IEtat etat){
        return (ali.contains(etat));
    }

}
