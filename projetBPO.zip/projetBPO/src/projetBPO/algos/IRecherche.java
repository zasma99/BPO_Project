package projetBPO.algos;

import projetBPO.jeux.IEtat;

public interface IRecherche {
    boolean existeChemin(IEtat etat);
}
