package projetBPO.algos;

import projetBPO.jeux.IEtat;

import java.util.Iterator;

public class LargeurDAbord implements IRecherche {

    public LargeurDAbord() {
    }

    @Override
    public boolean existeChemin(IEtat etat) {
        Historique h = new Historique();
        return existeChemin(etat , h);
    }

    private boolean existeChemin(IEtat etat , Historique h){
        boolean trouve = etat.estFinal();

        if(trouve){ return true ; }

        Iterator<IEtat> it = etat.iterator();

        while (!trouve && it.hasNext()){
            if (!h.contient(etat)) {
                h.ajouter(etat);
                trouve = existeChemin(it.next(), h);
            } else  {return false;}
        }
        return trouve ;
    }
}
