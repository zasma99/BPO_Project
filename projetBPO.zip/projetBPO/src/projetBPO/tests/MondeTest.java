package projetBPO.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import projetBPO.jeux.oups.*;

import static org.junit.jupiter.api.Assertions.*;

class MondeTest {
    private Piece room , room1 , room2;
    private boolean trappe ; private int etatTrappe ;
    private boolean tresor  ;
    private int noPiece ;

    private Passage way , way1 ,way2;

    private Monde world;
    private int nbSalles;
    private CollectionPieces piecesMonde;
    private CollectionPassages passagesMonde;

    @BeforeEach
    void setUp() {
        nbSalles = 15;
        /****** ROOM 0 ******/
        trappe = true ; etatTrappe = 0 ;
        tresor = false ;
        noPiece = 0 ;
        room = new Piece(trappe , etatTrappe , tresor , noPiece);

        /****** ROOM 1 ******/
        trappe = true ; etatTrappe = 1 ;
        tresor = false ;
        noPiece = 1 ;
        room1 = new Piece(trappe , etatTrappe , tresor , noPiece);

        /****** ROOM 2 ******/
        trappe = false ; etatTrappe = 0 ;
        tresor = true ;
        noPiece = 2 ;
        room2 = new Piece(trappe , etatTrappe , tresor , noPiece);

        /****** Collection de pièces du monde ******/
        piecesMonde = new CollectionPieces(room , room1 , room2);

        /****** Trappes commandées par passages ******/
        Piece[] trapped = new Piece[nbSalles];
        for(int i = 0 ; i < nbSalles ; i++){
            trapped[i] = room1;
        }

        /****** Collection de passages du monde ******/
        way = new Passage(room , room1 , trapped);
        way1 = new Passage(room , room2 , trapped);
        trapped[1] = room2;
        way2 = new Passage(room1 , room2 , trapped );

        passagesMonde = new CollectionPassages(way ,way1);

        /****** MONDE ******/
        world = new Monde(nbSalles);
        world.setPiecesMonde(piecesMonde);
        world.setPassagesMonde(passagesMonde);
    }


    @Test
    void ajouterPassage() {

        CollectionPassages expectedColl = new CollectionPassages(way , way1 , way2);
        world.ajouterPassage(room1.getNoPiece() , room2.getNoPiece());
        /*System.out.println(expectedColl.toString());
        System.out.println(passagesMonde);*/
        assertFalse(way2.equals(passagesMonde.passageI(room1 , room2)));

    }

    @Test
    void ajouterOuvertureFermetureTrappe() {
        world.ajouterOuvertureFermetureTrappe(room.getNoPiece() ,room1.getNoPiece() , room2.getNoPiece());
        assertEquals(1 , room.getEtatTrappe());
    }

}