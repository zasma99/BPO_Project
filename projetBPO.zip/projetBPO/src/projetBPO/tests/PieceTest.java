package projetBPO.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import projetBPO.jeux.oups.CollectionPassages;
import projetBPO.jeux.oups.Passage;
import projetBPO.jeux.oups.Piece;

import static org.junit.jupiter.api.Assertions.*;

class PieceTest {
    private Piece room , room1 , room2;
    private boolean trappe ; private int etatTrappe ;
    private boolean tresor  ;
    private int noPiece ;

    private Passage way , way1 , way2 ;
    private CollectionPassages collPass ;

    @BeforeEach
    void setUp() {

        /****** ROOM 0 ******/
        trappe = true ; etatTrappe = 0 ;
        tresor = false ;
        noPiece = 0 ;
        room = new Piece(trappe , etatTrappe , tresor , noPiece);

        /****** ROOM 1 ******/
        trappe = true ; etatTrappe = 1 ;
        tresor = false ;
        noPiece = 1 ;
        room1 = new Piece(trappe , etatTrappe , tresor , noPiece);

        /****** ROOM 2 ******/
        trappe = false ; etatTrappe = 0 ;
        tresor = true ;
        noPiece = 2 ;
        room2 = new Piece(trappe , etatTrappe , tresor , noPiece);

        Piece[] trappe = new Piece[100];
        /****** Passages entre les pièces ******/
        way = new Passage(room , room1 , trappe);
        way1 = new Passage(room , room2 , trappe);
        way2 = new Passage(room1 , room2 , trappe);

        //collPass = new CollectionPassages(way ,way1);



    }

    @Test
    void getNoPiece() {
        int num = room.getNoPiece();
        assertEquals(0 , num);
    }


}