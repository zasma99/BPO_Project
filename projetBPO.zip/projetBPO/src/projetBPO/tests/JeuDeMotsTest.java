package projetBPO.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import projetBPO.jeux.jeudemots.Dictionnaire;
import projetBPO.jeux.IEtat;
import projetBPO.jeux.jeudemots.JeuDeMots;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;
import static projetBPO.jeux.jeudemots.JeuDeMots.setDico;

class JeuDeMotsTest {
    private Dictionnaire dico ;
    private JeuDeMots jeu , jeu0 , jeu1;
    private String[] word;
    protected Iterator<IEtat> it ;
    private IEtat elm , elm1;

    @BeforeEach
    void setUp(){
        word = new String[]{"Gare","mare","the","real","gars"};
        dico = new Dictionnaire();

        String var = "Gare";

        jeu0 = new JeuDeMots("gare");
        jeu = new JeuDeMots("gars");
        jeu1 = new JeuDeMots("mare");


    }


    @Test
    void iterator() {
        dico.setMots(word);
        setDico(dico);

        it = jeu0.iterator();
        elm = it.next();
        assertTrue(jeu1.equals(elm));
        elm1 = it.next();
        assertEquals(elm1 , jeu);

        assertFalse(it.hasNext());
    }


}